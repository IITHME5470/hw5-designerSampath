 clc; clear; close all;

% Parameters
time_steps = [5001, 20001, 50001]; % Time steps to plot
num_processors = 16; % Adjust based on your setup
file_pattern = 'T_x_y_%06d_%04d.dat'; % File name format

% Loop over each time step
for t_idx = 1:length(time_steps)
    time_step = time_steps(t_idx);
    
    % Initialize arrays for storing data
    x_all = [];
    y_all = [];
    T_all = [];
    
    % Loop through each processor file
    for rank = 0:num_processors-1
        % Construct the file name
        file_name = sprintf(file_pattern, time_step, rank);
        
        % Check if the file exists
        if exist(file_name, 'file') == 2
            % Load data (Assuming three columns: x, y, T)
            data = load(file_name);
            
            % Append data to arrays
            x_all = [x_all; data(:,1)];
            y_all = [y_all; data(:,2)];
            T_all = [T_all; data(:,3)];
        else
            warning('File %s not found.', file_name);
        end
    end
    
    % Create a grid for plotting (Assumes uniform grid spacing)
    x_unique = unique(x_all);
    y_unique = unique(y_all);
    [X_grid, Y_grid] = meshgrid(x_unique, y_unique);

    % Interpolate scattered data onto the grid
    T_grid = griddata(x_all, y_all, T_all, X_grid, Y_grid, 'cubic');

    % Plot contour
    figure;
    contourf(X_grid, Y_grid, T_grid, 30, 'LineColor', 'none'); % 30 contour levels
    shading interp; % Smooth shading
    
    % Custom colormap: Blue (low values) → Red (high values)
    colormap(jet); % Alternative: colormap(hot), colormap(turbo)
    colorbar;
    caxis([min(T_all) max(T_all)]); % Ensure full range of temperature is shown

    % Labels and title
    xlabel('X Coordinate');
    ylabel('Y Coordinate');
    title(sprintf('Temperature Contour at Time Step %d', time_step));
    axis equal;
end

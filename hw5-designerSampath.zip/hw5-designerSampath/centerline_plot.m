clc; clear; close all;

% Constants
y_target = 0.500626;  % The specific y value to extract
timestep = 50001;         % Given timestep
max_ranks = 16;      % Adjust based on number of ranks
x_vals = [];          % Array to store x values
Temp_vals = [];       % Array to store temperature values

% Loop over all ranks to read data
for rank = 0:max_ranks-1
    filename = sprintf('T_x_y_%06d_%04d.dat', timestep, rank);
    
    % Check if file exists
    if exist(filename, 'file')
        % Read data (assuming 3 columns: x, y, T)
        data = dlmread(filename);
        x = data(:, 1);
        y = data(:, 2);
        T = data(:, 3);

        % Extract values where y matches the target
        idx = (y == y_target);
        x_vals = [x_vals; x(idx)];
        Temp_vals = [Temp_vals; T(idx)];
    else
        fprintf('Warning: File %s not found.\n', filename);
    end
end

% Sort data by x-values
[x_vals, sort_idx] = sort(x_vals);
Temp_vals = Temp_vals(sort_idx);

% Plot the extracted data
figure;
plot(x_vals, Temp_vals, 'bo-', 'LineWidth', 2, 'MarkerSize', 6);
xlabel('X values');
ylabel('Temperature');
title(sprintf('Temperature vs X at y = %.6f', y_target));
grid on;
legend('Temperature Profile');

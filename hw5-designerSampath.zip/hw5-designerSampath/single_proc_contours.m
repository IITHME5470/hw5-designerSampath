% Read the data from the file
tid = 40001;
rank = 2;
data = dlmread(sprintf('T_x_y_%06d_%04d.dat', tid, rank));

% Extract x, y, and z values
x = data(:,1);  % First column as x
y = data(:,2);  % Second column as y
z = data(:,3);  % Third column as z (contour variable)

% Create a grid for contour plotting
x_unique = unique(x);
y_unique = unique(y);
[X, Y] = meshgrid(x_unique, y_unique);

% Reshape z values to match grid structure
Z = griddata(x, y, z, X, Y, 'cubic'); % Interpolate data onto the grid

% Plot the contour with different colors
figure;
contourf(X, Y, Z, 20, 'LineColor', 'none'); % 20 contour levels with filled colors
colorbar; % Add color legend
xlabel('X-axis');
ylabel('Y-axis');
title('Contour Plot of Z values');

% Set colormap for better visualization
colormap jet; % Other options: parula, hot, cool, hsv, etc.
